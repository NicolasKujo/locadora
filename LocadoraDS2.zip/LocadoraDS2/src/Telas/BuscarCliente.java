
package Telas;

import Tabela.Client;
import util.ClienteDAO;
import java.sql.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class BuscarCliente extends javax.swing.JDialog {

    List<Tabela.Client> ListaClientes;
    Tabela.Client cliente;

    public BuscarCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        btnbuscarActionPerformed(null);
    }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelinterior = new javax.swing.JPanel();
        funcoesinternas = new javax.swing.JInternalFrame();
        jLabel25 = new javax.swing.JLabel();
        btnexcluir = new javax.swing.JButton();
        btneditar = new javax.swing.JButton();
        ediçãoclientes = new javax.swing.JInternalFrame();
        jLabel26 = new javax.swing.JLabel();
        btnsalvar = new javax.swing.JButton();
        clientecpf = new javax.swing.JTextField();
        clientenome = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        clienteende = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        clientetel = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        clientenasc = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        clientegen = new javax.swing.JComboBox();
        jLabel32 = new javax.swing.JLabel();
        clientecidade = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelacliente = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnbuscar = new javax.swing.JButton();
        campobusca = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        painelinterior.setBackground(new java.awt.Color(255, 255, 255));
        painelinterior.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        funcoesinternas.setClosable(true);
        funcoesinternas.setTitle("Funções internas");
        funcoesinternas.setVisible(false);

        jLabel25.setText("O que deseja fazer? ");

        btnexcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/Icons/1355332561_trash_16x16.gif"))); // NOI18N
        btnexcluir.setText("Excluir");
        btnexcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexcluirActionPerformed(evt);
            }
        });

        btneditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/Icons/1355332578_gtk-edit.png"))); // NOI18N
        btneditar.setText("Editar");
        btneditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout funcoesinternasLayout = new javax.swing.GroupLayout(funcoesinternas.getContentPane());
        funcoesinternas.getContentPane().setLayout(funcoesinternasLayout);
        funcoesinternasLayout.setHorizontalGroup(
            funcoesinternasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(funcoesinternasLayout.createSequentialGroup()
                .addGroup(funcoesinternasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(funcoesinternasLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(btneditar)
                        .addGap(32, 32, 32)
                        .addComponent(btnexcluir))
                    .addGroup(funcoesinternasLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel25)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        funcoesinternasLayout.setVerticalGroup(
            funcoesinternasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(funcoesinternasLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(funcoesinternasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnexcluir)
                    .addComponent(btneditar))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        painelinterior.add(funcoesinternas, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 280, 120));

        ediçãoclientes.setClosable(true);
        ediçãoclientes.setTitle("Edição dos clientes");
        ediçãoclientes.setVisible(false);
        ediçãoclientes.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setText("CPF");
        ediçãoclientes.getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 22, -1, -1));

        btnsalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/Icons/1355332578_gtk-edit.png"))); // NOI18N
        btnsalvar.setText("Salvar");
        btnsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalvarActionPerformed(evt);
            }
        });
        ediçãoclientes.getContentPane().add(btnsalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, -1, -1));
        ediçãoclientes.getContentPane().add(clientecpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(82, 19, 131, -1));
        ediçãoclientes.getContentPane().add(clientenome, new org.netbeans.lib.awtextra.AbsoluteConstraints(82, 57, 131, -1));

        jLabel27.setText("Nome");
        ediçãoclientes.getContentPane().add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 60, -1, -1));
        ediçãoclientes.getContentPane().add(clienteende, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 131, -1));

        jLabel28.setText("Endereço");
        ediçãoclientes.getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel29.setText("Telefone");
        ediçãoclientes.getContentPane().add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));
        ediçãoclientes.getContentPane().add(clientetel, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 131, -1));

        jLabel30.setText("Data Nasc");
        ediçãoclientes.getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));
        ediçãoclientes.getContentPane().add(clientenasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 131, -1));

        jLabel31.setText("Genero");
        ediçãoclientes.getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        clientegen.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "F", "M" }));
        ediçãoclientes.getContentPane().add(clientegen, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 130, -1));

        jLabel32.setText("Cidade");
        ediçãoclientes.getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));
        ediçãoclientes.getContentPane().add(clientecidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, 131, -1));

        painelinterior.add(ediçãoclientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, 270, 380));

        tabelacliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CPF", "Nome", "Endereço", "Telefone", "Cidade", "Data Nasc", "Genero"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelacliente.getTableHeader().setReorderingAllowed(false);
        tabelacliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaclienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelacliente);
        if (tabelacliente.getColumnModel().getColumnCount() > 0) {
            tabelacliente.getColumnModel().getColumn(0).setResizable(false);
            tabelacliente.getColumnModel().getColumn(1).setResizable(false);
            tabelacliente.getColumnModel().getColumn(2).setResizable(false);
            tabelacliente.getColumnModel().getColumn(3).setResizable(false);
            tabelacliente.getColumnModel().getColumn(4).setResizable(false);
            tabelacliente.getColumnModel().getColumn(5).setResizable(false);
            tabelacliente.getColumnModel().getColumn(6).setResizable(false);
        }

        painelinterior.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 144, 628, 354));

        jLabel1.setText("Digite o Nome ou CPF para realizar a busca");
        painelinterior.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        btnbuscar.setText("Buscar");
        btnbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarActionPerformed(evt);
            }
        });
        painelinterior.add(btnbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 80, -1, 40));

        campobusca.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        campobusca.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campobuscaKeyPressed(evt);
            }
        });
        painelinterior.add(campobusca, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 550, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelinterior, javax.swing.GroupLayout.DEFAULT_SIZE, 664, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelinterior, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarActionPerformed
        String texto = campobusca.getText();
        ClienteDAO cDAO = new ClienteDAO();
        ListaClientes = cDAO.BuscarCliente(texto);

        DefaultTableModel modelo = (DefaultTableModel) tabelacliente.getModel();
        modelo.setNumRows(0);

        for (int i = 0; i < ListaClientes.size(); i++) {
            Tabela.Client cli = (Tabela.Client) ListaClientes.get(i);
            modelo.addRow(new Object[]{cli.getCpf(), cli.getNome(), cli.getEnde(), cli.getTel(), cli.getCidade(), String.valueOf(cli.getNasc()), cli.getSexo()});
        }

        tabelacliente.repaint();
    }//GEN-LAST:event_btnbuscarActionPerformed

    private void campobuscaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campobuscaKeyPressed
        btnbuscarActionPerformed(null);
    }//GEN-LAST:event_campobuscaKeyPressed

    private void btneditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarActionPerformed
        funcoesinternas.setVisible(false);

        int indice = tabelacliente.getSelectedRow();
        cliente = (Tabela.Client) ListaClientes.get(indice);
        clientecpf.setText(String.valueOf(cliente.getCpf()));
        clientenome.setText(cliente.getNome());
        clienteende.setText(cliente.getEnde());
        clientecidade.setText(cliente.getCidade());
        clientetel.setText(cliente.getTel());
        clientenasc.setText(String.valueOf(cliente.getNasc()));

        if (cliente.getGenero().equals("M")) {
            clientegen.setSelectedIndex(1);
        } else {
            clientegen.setSelectedIndex(0);
        }

        ediçãoclientes.setVisible(true);
        tabelacliente.repaint();
        btnbuscarActionPerformed(null);
    }//GEN-LAST:event_btneditarActionPerformed

    private void btnsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalvarActionPerformed
        String cpf = clientecpf.getText();

        if (!cpf.isEmpty()) {
            cliente.setCpf(Integer.valueOf(clientecpf.getText()));
            cliente.setNome(clientenome.getText());
            cliente.setEnde(clienteende.getText());
            cliente.setNasc(Date.valueOf(clientenasc.getText()));
            cliente.setCidade(clientecidade.getText());
            cliente.setTel(clientetel.getText());
            cliente.setGenero(String.valueOf(clientegen.getSelectedItem()));
        }

        ClienteDAO cDAO = new ClienteDAO();
        cDAO.Salvar(cliente);
        ediçãoclientes.setVisible(false);
    }//GEN-LAST:event_btnsalvarActionPerformed

    private void btnexcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexcluirActionPerformed
        int indice = tabelacliente.getSelectedRow();
        cliente = (Tabela.Client) ListaClientes.get(indice);
        indice = cliente.getCpf();
        cliente.setCpf(indice);

        ClienteDAO cDAO = new ClienteDAO();
        cDAO.Excluir(cliente);

        JOptionPane.showMessageDialog(null, "Cliente foi excluido com sucesso");

        tabelacliente.removeAll();
        tabelacliente.repaint();
    }//GEN-LAST:event_btnexcluirActionPerformed

    private void tabelaclienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaclienteMouseClicked
        funcoesinternas.setVisible(true);
    }//GEN-LAST:event_tabelaclienteMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BuscarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BuscarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BuscarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BuscarCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BuscarCliente dialog = new BuscarCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbuscar;
    private javax.swing.JButton btneditar;
    private javax.swing.JButton btnexcluir;
    private javax.swing.JButton btnsalvar;
    private javax.swing.JTextField campobusca;
    private javax.swing.JTextField clientecidade;
    private javax.swing.JTextField clientecpf;
    private javax.swing.JTextField clienteende;
    private javax.swing.JComboBox clientegen;
    private javax.swing.JTextField clientenasc;
    private javax.swing.JTextField clientenome;
    private javax.swing.JTextField clientetel;
    private javax.swing.JInternalFrame ediçãoclientes;
    private javax.swing.JInternalFrame funcoesinternas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel painelinterior;
    private javax.swing.JTable tabelacliente;
    // End of variables declaration//GEN-END:variables

}
