package Telas;

import java.sql.Date;
import java.util.List;
import util.ClienteDAO;

public class Cliente extends javax.swing.JFrame {

    public Cliente() {
        initComponents();
    }

    public class BuscarCliente extends javax.swing.JDialog{
        List<Tabela.Client> ListaClientes;
        Tabela.Client cliente;
        
        public BuscarCliente(java.awt.Frame parent, boolean modal){
            super(parent, modal);
            initComponents();
            procurarActionPerformed(null);
        }

        private BuscarCliente() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        voltar = new javax.swing.JToggleButton();
        procurar = new javax.swing.JButton();
        novo = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cidade = new javax.swing.JTextField();
        nome = new javax.swing.JTextField();
        endereço = new javax.swing.JTextField();
        telefone = new javax.swing.JTextField();
        sexo = new javax.swing.JComboBox<String>();
        datanasc = new javax.swing.JTextField();
        concluir1 = new javax.swing.JButton();
        deletar1 = new javax.swing.JButton();
        cpf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cliente_fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titulo.setFont(new java.awt.Font("Corbel", 1, 48)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setText("CLIENTES");
        getContentPane().add(titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 120, 220, 60));

        voltar.setBackground(new java.awt.Color(34, 35, 37));
        voltar.setFont(new java.awt.Font("Eras Bold ITC", 1, 24)); // NOI18N
        voltar.setForeground(new java.awt.Color(255, 255, 255));
        voltar.setText("<");
        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                voltarMouseClicked(evt);
            }
        });
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        getContentPane().add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 614, 160, 30));

        procurar.setBackground(new java.awt.Color(34, 35, 37));
        procurar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        procurar.setForeground(new java.awt.Color(255, 255, 255));
        procurar.setText("PROCURAR");
        procurar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        procurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                procurarActionPerformed(evt);
            }
        });
        getContentPane().add(procurar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 90, 30));

        novo.setBackground(new java.awt.Color(34, 35, 37));
        novo.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        novo.setForeground(new java.awt.Color(255, 255, 255));
        novo.setText("NOVO");
        novo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        getContentPane().add(novo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 80, 30));

        editar.setBackground(new java.awt.Color(34, 35, 37));
        editar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        editar.setForeground(new java.awt.Color(255, 255, 255));
        editar.setText("EDITAR");
        editar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });
        getContentPane().add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 90, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("CPF");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, -1, -1));

        cidade.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        cidade.setBorder(null);
        getContentPane().add(cidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 230, 360, 20));

        nome.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        nome.setBorder(null);
        getContentPane().add(nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 290, 360, 20));

        endereço.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        endereço.setBorder(null);
        getContentPane().add(endereço, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 360, 20));

        telefone.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        telefone.setBorder(null);
        getContentPane().add(telefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 360, 20));

        sexo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "F", "M" }));
        sexo.setBorder(null);
        getContentPane().add(sexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 290, 360, -1));

        datanasc.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        datanasc.setBorder(null);
        getContentPane().add(datanasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 350, 360, 20));

        concluir1.setBackground(new java.awt.Color(204, 255, 255));
        concluir1.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        concluir1.setText("CONCLUIR");
        concluir1.setBorder(null);
        concluir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                concluir1ActionPerformed(evt);
            }
        });
        getContentPane().add(concluir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 500, 360, 30));

        deletar1.setBackground(new java.awt.Color(182, 75, 76));
        deletar1.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        deletar1.setText("DELETAR");
        deletar1.setBorder(null);
        deletar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletar1ActionPerformed(evt);
            }
        });
        getContentPane().add(deletar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 560, 360, 30));

        cpf.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        cpf.setBorder(null);
        getContentPane().add(cpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, 360, 20));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nome");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Endereço");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 320, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Telefone");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 380, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Cidade");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 200, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Sexo");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 260, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Data de Nascimento");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, -1, -1));

        cliente_fundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cliente.png"))); // NOI18N
        getContentPane().add(cliente_fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1330, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_voltarActionPerformed

    private void voltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarMouseClicked
    Inicio inicio1 = new Inicio();
    
    inicio1.setVisible(true);
    inicio1.setLocationRelativeTo(null);
    
    this.setVisible(false);
    }//GEN-LAST:event_voltarMouseClicked

    private void concluir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_concluir1ActionPerformed
        Tabela.Client cliente = new Tabela.Client();
        
        cliente.setCpf(Integer.valueOf(cpf.getText()));
        cliente.setNome(nome.getText());
        cliente.setEnde(endereço.getText());
        cliente.setTel(telefone.getText());
        cliente.setDataNasc(Date.valueOf(datanasc.getText()));
        cliente.setCidade(cidade.getText());
        cliente.setSexo((String) sexo.getSelectedItem());
        
        ClienteDAO cDAO = new ClienteDAO();
        cDAO.Salvar(cliente);
        bloqcampos();
    }//GEN-LAST:event_concluir1ActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        editacampos();
    }//GEN-LAST:event_editarActionPerformed

    private void deletar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletar1ActionPerformed
        Tabela.Client cliente = new Tabela.Client();
        cliente.setCpf(Integer.valueOf(cpf.getText()));
        
        ClienteDAO cDAO = new ClienteDAO();
        cDAO.Excluir(cliente);
        
        habilitacampos();
        bloqcampos();
    }//GEN-LAST:event_deletar1ActionPerformed

    private void procurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_procurarActionPerformed
        int codcpf = Integer.valueOf(cpf.getText());
        
        Tabela.Client cliente = new Tabela.Client();
        ClienteDAO cDAO = new ClienteDAO();
        cliente = cDAO.Buscar(codcpf, cliente);
        
        cpf.setText(String.valueOf(cliente.getCpf()));
        nome.setText(String.valueOf(cliente.getNome()));
        telefone.setText(String.valueOf(cliente.getTel()));
        cidade.setText(String.valueOf(cliente.getCidade()));
        datanasc.setText(String.valueOf(cliente.getDataNasc()));
        sexo.setSelectedItem(String.valueOf(cliente.getSexo()));
        
        bloqcampos(); 
        
    }//GEN-LAST:event_procurarActionPerformed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cidade;
    private javax.swing.JLabel cliente_fundo;
    private javax.swing.JButton concluir1;
    private javax.swing.JTextField cpf;
    private javax.swing.JTextField datanasc;
    private javax.swing.JButton deletar1;
    private javax.swing.JButton editar;
    private javax.swing.JTextField endereço;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField nome;
    private javax.swing.JButton novo;
    private javax.swing.JButton procurar;
    private javax.swing.JComboBox<String> sexo;
    private javax.swing.JTextField telefone;
    private javax.swing.JLabel titulo;
    private javax.swing.JToggleButton voltar;
    // End of variables declaration//GEN-END:variables

    private void bloqcampos() {
        cidade.setEnabled(false);
        cpf.setEnabled(false);
        telefone.setEnabled(false);
        datanasc.setEnabled(false);
        nome.setEnabled(false);
        sexo.setEnabled(false);
        endereço.setEnabled(false);
    }
    
    void editacampos(){
        cidade.setEnabled(true);
        cpf.setEnabled(true);
        telefone.setEnabled(true);
        datanasc.setEnabled(true);
        nome.setEnabled(true);
        sexo.setEnabled(true);
        endereço.setEnabled(true);
    }

    private void habilitacampos() {
        cidade.setEnabled(true);
        cpf.setEnabled(true);
        telefone.setEnabled(true);
        datanasc.setEnabled(true);
        nome.setEnabled(true);
        sexo.setEnabled(true);
        endereço.setEnabled(true);
        telefone.setText("");
        cidade.setText("");
        cpf.setText("");
        datanasc.setText("");
        nome.setText("");
        endereço.setText("");
    }
    
}

