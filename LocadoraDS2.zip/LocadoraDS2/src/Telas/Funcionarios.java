package Telas;

import Tabela.Departamento;
import java.sql.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import util.DeptoDAO;
import java.math.BigDecimal;
import java.util.List;
import util.FuncionarioDAO;

public class Funcionarios extends javax.swing.JFrame {
    
    List<Departamento> departamento;

    public Funcionarios() {
        initComponents();
        ListaDepartamento();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        deletar2 = new javax.swing.JButton();
        concluir2 = new javax.swing.JButton();
        voltar = new javax.swing.JToggleButton();
        novo = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        procurar = new javax.swing.JButton();
        matricula = new javax.swing.JTextField();
        nome = new javax.swing.JTextField();
        admissao = new javax.swing.JTextField();
        funcsalario = new javax.swing.JTextField();
        funcdepto = new javax.swing.JComboBox<String>();
        sexo = new javax.swing.JComboBox<String>();
        ativo = new javax.swing.JComboBox<String>();
        filho = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        funcionarios_fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titulo.setFont(new java.awt.Font("Corbel", 1, 48)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setText("FUNCIONARIOS");
        getContentPane().add(titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 130, -1, -1));

        deletar2.setBackground(new java.awt.Color(182, 75, 76));
        deletar2.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        deletar2.setText("DELETAR");
        deletar2.setBorder(null);
        getContentPane().add(deletar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 560, 360, 30));

        concluir2.setBackground(new java.awt.Color(204, 255, 255));
        concluir2.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        concluir2.setText("CONCLUIR");
        concluir2.setBorder(null);
        concluir2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                concluir2ActionPerformed(evt);
            }
        });
        getContentPane().add(concluir2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 500, 360, 30));

        voltar.setBackground(new java.awt.Color(34, 35, 37));
        voltar.setFont(new java.awt.Font("Eras Bold ITC", 1, 24)); // NOI18N
        voltar.setForeground(new java.awt.Color(255, 255, 255));
        voltar.setText("<");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        getContentPane().add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 660, 160, 30));

        novo.setBackground(new java.awt.Color(34, 35, 37));
        novo.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        novo.setForeground(new java.awt.Color(255, 255, 255));
        novo.setText("NOVO");
        novo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        getContentPane().add(novo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 80, 30));

        editar.setBackground(new java.awt.Color(34, 35, 37));
        editar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        editar.setForeground(new java.awt.Color(255, 255, 255));
        editar.setText("EDITAR");
        editar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        getContentPane().add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 90, 30));

        procurar.setBackground(new java.awt.Color(34, 35, 37));
        procurar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        procurar.setForeground(new java.awt.Color(255, 255, 255));
        procurar.setText("PROCURAR");
        procurar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        getContentPane().add(procurar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 90, 30));

        matricula.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        matricula.setBorder(null);
        getContentPane().add(matricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, 360, 20));

        nome.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        nome.setBorder(null);
        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });
        getContentPane().add(nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 290, 360, 20));

        admissao.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        admissao.setBorder(null);
        getContentPane().add(admissao, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 360, 20));

        funcsalario.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        funcsalario.setBorder(null);
        getContentPane().add(funcsalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 360, 20));

        funcdepto.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5" }));
        funcdepto.setBorder(null);
        getContentPane().add(funcdepto, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 230, 360, 20));

        sexo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "F", "M" }));
        sexo.setBorder(null);
        getContentPane().add(sexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 290, 360, -1));

        ativo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", " " }));
        ativo.setBorder(null);
        getContentPane().add(ativo, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 350, 360, -1));

        filho.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        filho.setBorder(null);
        getContentPane().add(filho, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 410, 360, 20));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Matricula");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nome");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Departamento");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 200, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Salario");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 380, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Admissão");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 320, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Sexo");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 260, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Ativo");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Filho");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 380, -1, -1));

        funcionarios_fundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cliente.png"))); // NOI18N
        funcionarios_fundo.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(funcionarios_fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
    Inicio inicio1 = new Inicio();
    
    inicio1.setVisible(true);
    inicio1.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_voltarActionPerformed

    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeActionPerformed

    private void concluir2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_concluir2ActionPerformed
        Tabela.Funcionario funcionario = new Tabela.Funcionario();
        
        Departamento depto = new Departamento();
        depto = departamento.get(funcdepto.getSelectedIndex());
       
        funcionario.setMatricula(Integer.valueOf(matricula.getText()));
        funcionario.setNome(nome.getText());
        funcionario.setAdmissao(Date.valueOf(admissao.getText()));
        funcionario.setDepto(depto.getCod());
        funcionario.setFilho(Integer.valueOf(filho.getText()));
        funcionario.setSexo((Character) sexo.getSelectedItem());
        
        Double salario = Double.valueOf(funcsalario.getText());
        funcionario.setSalario(BigDecimal.valueOf(salario));
        
        FuncionarioDAO fDAO = new FuncionarioDAO();
        fDAO.Salvar(funcionario);
        
        bloqcampos();
    }//GEN-LAST:event_concluir2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Funcionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Funcionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Funcionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Funcionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Funcionarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField admissao;
    private javax.swing.JComboBox<String> ativo;
    private javax.swing.JButton concluir2;
    private javax.swing.JButton deletar2;
    private javax.swing.JButton editar;
    private javax.swing.JTextField filho;
    private javax.swing.JComboBox<String> funcdepto;
    private javax.swing.JLabel funcionarios_fundo;
    private javax.swing.JTextField funcsalario;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField matricula;
    private javax.swing.JTextField nome;
    private javax.swing.JButton novo;
    private javax.swing.JButton procurar;
    private javax.swing.JComboBox<String> sexo;
    private javax.swing.JLabel titulo;
    private javax.swing.JToggleButton voltar;
    // End of variables declaration//GEN-END:variables

    private void ListaDepartamento() {
       funcdepto.removeAllItems();
       DeptoDAO dDAO =  new DeptoDAO();
       funcdepto = (JComboBox<String>) dDAO.ListaDepartamento();
       
       DefaultComboBoxModel combo = (DefaultComboBoxModel) funcdepto.getModel();
       for (int i = 0; i < departamento.size(); i++){
           Departamento depto = departamento.get(i);
           combo.addElement(depto.getNome());
           System.out.print(i);
       }
       
       funcdepto.repaint();
    }

     private void bloqcampos() {
        matricula.setEnabled(false);
        funcdepto.setEnabled(false);
        admissao.setEnabled(false);
        funcsalario.setEnabled(false);
        nome.setEnabled(false);
        sexo.setEnabled(false);
        filho.setEnabled(false);
        ativo.setEnabled(false);
    }
    
    
}
