package Telas;

public class Inicio extends javax.swing.JFrame {

    public void chamar(){
    
        show();
            setLocationRelativeTo(null);
        
    }
    
    public Inicio() {
        initComponents();
        
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cliente = new javax.swing.JButton();
        funcionario = new javax.swing.JButton();
        veiculos = new javax.swing.JButton();
        os = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cliente.setBackground(new java.awt.Color(22, 22, 23));
        cliente.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        cliente.setForeground(new java.awt.Color(255, 255, 255));
        cliente.setText("CLIENTE");
        cliente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        cliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clienteMouseClicked(evt);
            }
        });
        cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clienteActionPerformed(evt);
            }
        });
        getContentPane().add(cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 560, 50));

        funcionario.setBackground(new java.awt.Color(22, 22, 23));
        funcionario.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        funcionario.setForeground(new java.awt.Color(255, 255, 255));
        funcionario.setText("FUNCIONÁRIOS");
        funcionario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        funcionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                funcionarioMouseClicked(evt);
            }
        });
        funcionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                funcionarioActionPerformed(evt);
            }
        });
        getContentPane().add(funcionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, 560, 50));

        veiculos.setBackground(new java.awt.Color(22, 22, 23));
        veiculos.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        veiculos.setForeground(new java.awt.Color(255, 255, 255));
        veiculos.setText("VEÍCULOS");
        veiculos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        veiculos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                veiculosMouseClicked(evt);
            }
        });
        veiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                veiculosActionPerformed(evt);
            }
        });
        getContentPane().add(veiculos, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 560, 50));

        os.setBackground(new java.awt.Color(22, 22, 23));
        os.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        os.setForeground(new java.awt.Color(255, 255, 255));
        os.setText("ORDEM DE SERVIÇO");
        os.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        os.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                osMouseClicked(evt);
            }
        });
        os.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                osActionPerformed(evt);
            }
        });
        getContentPane().add(os, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, 560, 50));

        titulo.setBackground(new java.awt.Color(255, 255, 255));
        titulo.setFont(new java.awt.Font("Ebrima", 3, 24)); // NOI18N
        titulo.setText("TELA INICIO");
        getContentPane().add(titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, 150, 34));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundo.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void osActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_osActionPerformed

    }//GEN-LAST:event_osActionPerformed

    private void veiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_veiculosActionPerformed

    }//GEN-LAST:event_veiculosActionPerformed

    private void funcionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_funcionarioActionPerformed

    }//GEN-LAST:event_funcionarioActionPerformed

    private void clienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clienteMouseClicked
    Cliente clientes = new Cliente();
    
    clientes.setVisible(true);
    clientes.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_clienteMouseClicked

    private void funcionarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_funcionarioMouseClicked
    Funcionarios funcionario = new Funcionarios();
    
    funcionario.setVisible(true);
    funcionario.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_funcionarioMouseClicked

    private void veiculosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_veiculosMouseClicked
    Veiculos veiculo = new Veiculos();
    
    veiculo.setVisible(true);
    veiculo.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_veiculosMouseClicked

    private void osMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_osMouseClicked
    Ordens_de_Servico os = new Ordens_de_Servico();
    
    os.setVisible(true);
    os.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_osMouseClicked

    private void clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clienteActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cliente;
    private javax.swing.JButton funcionario;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton os;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton veiculos;
    // End of variables declaration//GEN-END:variables
}
