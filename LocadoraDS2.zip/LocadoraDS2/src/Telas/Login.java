package Telas;

import classes.Usuario;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import util.UsuarioDAO;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Entrar = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        Login = new javax.swing.JTextField();
        Fechar = new javax.swing.JButton();
        Senha = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Entrar.setBackground(new java.awt.Color(34, 35, 37));
        Entrar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        Entrar.setForeground(new java.awt.Color(242, 242, 242));
        Entrar.setText("Entrar");
        Entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarActionPerformed(evt);
            }
        });
        getContentPane().add(Entrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, -1, -1));

        titulo.setBackground(new java.awt.Color(255, 255, 255));
        titulo.setFont(new java.awt.Font("Ebrima", 3, 24)); // NOI18N
        titulo.setText("TELA LOGIN");
        getContentPane().add(titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, 150, -1));

        Login.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        Login.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Login.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginActionPerformed(evt);
            }
        });
        Login.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoginKeyPressed(evt);
            }
        });
        getContentPane().add(Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 260, -1));

        Fechar.setBackground(new java.awt.Color(34, 35, 37));
        Fechar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        Fechar.setForeground(new java.awt.Color(242, 242, 242));
        Fechar.setText("Fechar");
        Fechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FecharActionPerformed(evt);
            }
        });
        getContentPane().add(Fechar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, -1, -1));

        Senha.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        Senha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Senha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SenhaActionPerformed(evt);
            }
        });
        Senha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SenhaKeyPressed(evt);
            }
        });
        getContentPane().add(Senha, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 260, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Usuario");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, -1, -1));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Senha");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, -1));

        fundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundo.png"))); // NOI18N
        getContentPane().add(fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -60, 950, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginActionPerformed
        Tabela.Usuario usuario;
        UsuarioDAO uDAO = new UsuarioDAO();
        String login = campologin.getText(), senha = String.valueOf(Senha.getPassword());
        
        /*usuario = uDAO.Verifica(login, senha);
        
        if(usuario.getStatus() == true){
            JOptionPane.showMessageDialog(null, "Usuario logado");
            
            JFrame Principal = new Inicio();
            Principal.setVisible(true);
            Principal.pack();
            Principal.setLocationRelativeTo(null);
            Principal.setExtendedState(JFrame.MAXIMIZED_BOTH);
            Principal.setResizable(false);
            dispose();
            
        }else{
            JOptionPane.showMessageDialog(null, "Usuario não existe ou esta desativado");
        }
        */
    }//GEN-LAST:event_LoginActionPerformed

    private void EntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarActionPerformed
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        String login = Login.getText();
        String senha = String.valueOf(Senha.getPassword());

        Usuario usuarioatual = new Usuario(login, senha);

        usuarioDAO.VerificarUsuario(usuarioatual.getLogin(login), usuarioatual.getSenha(senha));
    }//GEN-LAST:event_EntrarActionPerformed

    private void FecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FecharActionPerformed
        System.exit(0);
    }//GEN-LAST:event_FecharActionPerformed

    private void SenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SenhaActionPerformed
     
    }//GEN-LAST:event_SenhaActionPerformed

    private void LoginKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoginKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            EntrarActionPerformed(null);
        }
    }//GEN-LAST:event_LoginKeyPressed

    private void SenhaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SenhaKeyPressed
         if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            EntrarActionPerformed(null);
        }
    }//GEN-LAST:event_SenhaKeyPressed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Entrar;
    private javax.swing.JButton Fechar;
    private javax.swing.JTextField Login;
    private javax.swing.JPasswordField Senha;
    private javax.swing.JLabel fundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
    
}