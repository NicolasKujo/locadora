package Telas;

import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) {
        JFrame Login = new Login();
        Login.setVisible(true);
        Login.setLocationRelativeTo(null);
        
        
    }
    
}