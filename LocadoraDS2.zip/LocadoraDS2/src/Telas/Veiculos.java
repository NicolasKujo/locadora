package Telas;

import java.util.List;
import util.VeiculoDAO;


public class Veiculos extends javax.swing.JFrame {


    public Veiculos() {
        initComponents();
    }
    
    public class BuscarVeiculos extends javax.swing.JDialog{
        List<Tabela.Veiculos> ListaVeiculos;
        Tabela.Veiculos veiculo;
        
        public BuscarVeiculos(java.awt.Frame parent, boolean modal){
            super(parent, modal);
            initComponents();
            procurarActionPerformed(null);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        novo = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        procurar = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        placa = new javax.swing.JTextField();
        marca = new javax.swing.JTextField();
        modelo = new javax.swing.JTextField();
        cor = new javax.swing.JTextField();
        ano = new javax.swing.JTextField();
        voltar = new javax.swing.JToggleButton();
        combustivel = new javax.swing.JComboBox<String>();
        categoria = new javax.swing.JComboBox<String>();
        alocado = new javax.swing.JComboBox<String>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        concluir2 = new javax.swing.JButton();
        deletar2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        novo.setBackground(new java.awt.Color(34, 35, 37));
        novo.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        novo.setForeground(new java.awt.Color(255, 255, 255));
        novo.setText("NOVO");
        novo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                novoActionPerformed(evt);
            }
        });
        getContentPane().add(novo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 80, 30));

        editar.setBackground(new java.awt.Color(34, 35, 37));
        editar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        editar.setForeground(new java.awt.Color(255, 255, 255));
        editar.setText("EDITAR");
        editar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });
        getContentPane().add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 90, 30));

        procurar.setBackground(new java.awt.Color(34, 35, 37));
        procurar.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        procurar.setForeground(new java.awt.Color(255, 255, 255));
        procurar.setText("PROCURAR");
        procurar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        procurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                procurarActionPerformed(evt);
            }
        });
        getContentPane().add(procurar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 90, 30));

        titulo.setFont(new java.awt.Font("Corbel", 1, 48)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setText("VEÍCULOS");
        getContentPane().add(titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, -1, -1));

        placa.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        placa.setBorder(null);
        getContentPane().add(placa, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 230, 360, 20));

        marca.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        marca.setBorder(null);
        getContentPane().add(marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 290, 360, 20));

        modelo.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        modelo.setBorder(null);
        getContentPane().add(modelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 360, 20));

        cor.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        cor.setBorder(null);
        getContentPane().add(cor, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 360, 20));

        ano.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        ano.setBorder(null);
        getContentPane().add(ano, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 410, 360, 20));

        voltar.setBackground(new java.awt.Color(34, 35, 37));
        voltar.setFont(new java.awt.Font("Eras Bold ITC", 1, 24)); // NOI18N
        voltar.setForeground(new java.awt.Color(255, 255, 255));
        voltar.setText("<");
        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                voltarMouseClicked(evt);
            }
        });
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        getContentPane().add(voltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 660, 160, 30));

        combustivel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "F", "G", "A", "D" }));
        combustivel.setBorder(null);
        getContentPane().add(combustivel, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 350, 360, -1));

        categoria.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4" }));
        categoria.setBorder(null);
        getContentPane().add(categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 230, 360, 20));

        alocado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1 ", "0" }));
        alocado.setBorder(null);
        getContentPane().add(alocado, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 290, 360, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Placa");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Marca");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Modelo");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 320, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Cor");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 380, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Categoria");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 200, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Alocado");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 260, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Combustivel");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Ano");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 380, -1, -1));

        concluir2.setBackground(new java.awt.Color(204, 255, 255));
        concluir2.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        concluir2.setText("CONCLUIR");
        concluir2.setBorder(null);
        concluir2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                concluir2ActionPerformed(evt);
            }
        });
        getContentPane().add(concluir2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 360, 30));

        deletar2.setBackground(new java.awt.Color(182, 75, 76));
        deletar2.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        deletar2.setText("DELETAR");
        deletar2.setBorder(null);
        deletar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletar2ActionPerformed(evt);
            }
        });
        getContentPane().add(deletar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 570, 360, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cliente.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_voltarActionPerformed

    private void voltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_voltarMouseClicked
    Inicio inicio1 = new Inicio();
    
    inicio1.setVisible(true);
    inicio1.setLocationRelativeTo(null);
    
    this.setVisible(false);
    
    }//GEN-LAST:event_voltarMouseClicked

    private void concluir2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_concluir2ActionPerformed
     Tabela.Veiculos veiculo = new Tabela.Veiculos();
        
        veiculo.setPlaca(String.valueOf(placa.getText()));
        veiculo.setMarca(marca.getText());
        veiculo.setModelo(modelo.getText());
        veiculo.setCor(cor.getText());
        veiculo.setCat((Integer) categoria.getSelectedItem());
        veiculo.setStatusAlocado((Boolean) (alocado.getSelectedItem()));
        veiculo.setComb((Character) combustivel.getSelectedItem());
        veiculo.setAno(Integer.valueOf(ano.getText()));
        
        VeiculoDAO vDAO = new VeiculoDAO();
        vDAO.Salvar(veiculo);
        bloqcampos();
    }//GEN-LAST:event_concluir2ActionPerformed

    private void deletar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletar2ActionPerformed
       Tabela.Veiculos veiculo = new Tabela.Veiculos();
        veiculo.setPlaca(String.valueOf(placa.getText()));
        
        VeiculoDAO vDAO = new VeiculoDAO();
        vDAO.Excluir(veiculo);
        
        habilitacampos();
        bloqcampos();
    }//GEN-LAST:event_deletar2ActionPerformed

    private void novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_novoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_novoActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        editacampos();
    }//GEN-LAST:event_editarActionPerformed

    private void procurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_procurarActionPerformed
        int codplaca = Integer.valueOf(placa.getText());
        
        Tabela.Veiculos veiculo = new Tabela.Veiculos();
        VeiculoDAO vDAO = new VeiculoDAO();
        veiculo = vDAO.Buscar(codplaca, veiculo);
        
        placa.setText(String.valueOf(veiculo.getPlaca()));
        marca.setText(String.valueOf(veiculo.getMarca()));
        modelo.setText(String.valueOf(veiculo.getModelo()));
        cor.setText(String.valueOf(veiculo.getCor()));
        categoria.setSelectedItem(String.valueOf(veiculo.getCat()));
        alocado.setSelectedItem(String.valueOf(veiculo.getStatusAlocado()));
        combustivel.setSelectedItem(String.valueOf(veiculo.getComb()));
        ano.setText(String.valueOf(veiculo.getAno()));
    }//GEN-LAST:event_procurarActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Veiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Veiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Veiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Veiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> alocado;
    private javax.swing.JTextField ano;
    private javax.swing.JComboBox<String> categoria;
    private javax.swing.JComboBox<String> combustivel;
    private javax.swing.JButton concluir2;
    private javax.swing.JTextField cor;
    private javax.swing.JButton deletar2;
    private javax.swing.JButton editar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField marca;
    private javax.swing.JTextField modelo;
    private javax.swing.JButton novo;
    private javax.swing.JTextField placa;
    private javax.swing.JButton procurar;
    private javax.swing.JLabel titulo;
    private javax.swing.JToggleButton voltar;
    // End of variables declaration//GEN-END:variables
 private void bloqcampos() {
        placa.setEnabled(false);
        marca.setEnabled(false);
        cor.setEnabled(false);
        modelo.setEnabled(false);
        alocado.setEnabled(false);
        ano.setEnabled(false);
        categoria.setEnabled(false);
        combustivel.setEnabled(false);
 }
    
    void editacampos(){
        placa.setEnabled(true);
        marca.setEnabled(true);
        cor.setEnabled(true);
        modelo.setEnabled(true);
        alocado.setEnabled(true);
        ano.setEnabled(true);
        categoria.setEnabled(true);
        combustivel.setEnabled(true);
    }

    private void habilitacampos() {
        placa.setEnabled(true);
        marca.setEnabled(true);
        cor.setEnabled(true);
        modelo.setEnabled(true);
        alocado.setEnabled(true);
        ano.setEnabled(true);
        categoria.setEnabled(true);
        combustivel.setEnabled(true);
        placa.setText("");
        marca.setText("");
        cor.setText("");
        modelo.setText("");
        ano.setText("");
    }
    
}