package Telas;


class campologin {

    static String getText() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
