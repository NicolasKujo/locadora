package classes;

public class Usuario {
    
    private static String login;
    private static String senha;
    
    public Usuario(String login, String senha){
        setLogin(login);
        setSenha(senha);
    }
    
    public String getLogin(String login){
        return login;
    }
    
     public void setLogin(String login){
        this.login = login;
    }
     
    public String getSenha(String senha){
        return senha;
    }
    
     public void setSenha(String senha){
        this.senha = senha;
    }
}
