package util;

import Tabela.Client;
import Telas.Cliente;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class ClienteDAO {
    
    private Session sessao;
    
    public ClienteDAO(){
        this.sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void Salvar(Client cliente){
        Transaction t = sessao.beginTransaction();
        sessao.saveOrUpdate(cliente);
        t.commit();
    }
    
    public void Editar(Client cliente){
        Transaction t = sessao.beginTransaction();
        sessao.update(cliente);
        t.commit();
    }
        
    public void Excluir(Client cliente){
        Transaction t = sessao.beginTransaction();
        sessao.delete(cliente);
        t.commit();
    }
    
    public Client Buscar(int codigo, Client client){
        Transaction t = sessao.beginTransaction();
        Tabela.Client cliente = new Tabela.Client();
        try{
            client = (Client) sessao.get(Client.class, codigo);
            t.commit();
        }catch (Error e){
            System.out.println(e.getMessage());
        }
        sessao.close();
        return cliente;
    }
    
    public List<Client>BuscarCliente(String texto){
        int numero = 0;
        try{
            numero = Integer.valueOf(texto);
        } catch(NumberFormatException e){
            System.out.println("O " + texto + " não é um numero.");
        }
        texto = "%" + texto + "%";
        
        Query query = sessao.createQuery("from Cliente" + "where cpf = :cod or nome like :detalhe");
        query.setInteger("cod", numero);
        query.setString("detalhe", texto);
        
        List<Client> cli = (List<Client>) query.list();
        return cli;
        
    }
        
}


