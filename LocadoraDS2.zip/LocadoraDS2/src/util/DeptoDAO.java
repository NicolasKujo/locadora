package util;

import Tabela.Departamento;
import org.hibernate.Session;
import java.util.List;
import org.hibernate.Query;


public class DeptoDAO {
    
    private Session sessao;
     
    public List<Departamento> ListaDepartamento(){
        Query query = sessao.createQuery("from Departamento");
        List<Departamento> listdepto = (List<Departamento>) query.list();
        return listdepto;
    }
    
}
