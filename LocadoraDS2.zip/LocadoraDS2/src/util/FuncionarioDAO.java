package util;

import Tabela.Client;
import Tabela.Funcionario;

import org.hibernate.Session;
import org.hibernate.Transaction;


public class FuncionarioDAO {
    
    private Session sessao;
    
    public FuncionarioDAO (){
        this.sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void Salvar(Funcionario funcionario){
        Transaction t = sessao.beginTransaction();
        sessao.saveOrUpdate(funcionario);
        t.commit();
    }
    
    public void Editar(Funcionario funcionario){
        Transaction t = sessao.beginTransaction();
        sessao.update(funcionario);
        t.commit();
    }
        
    public void Excluir(Funcionario funcionario){
        Transaction t = sessao.beginTransaction();
        sessao.delete(funcionario);
        t.commit();
    }
    
    public Funcionario Buscar(int codigo, Funcionario funcionario){
        Transaction t = sessao.beginTransaction();
        Tabela.Funcionario funcionarios = new Tabela.Funcionario();
        try{
            funcionario = (Funcionario) sessao.get(Funcionario.class, codigo);
            t.commit();
        }catch (Error e){
            System.out.println(e.getMessage());
        }
        sessao.close();
        return funcionario;
    }

}
