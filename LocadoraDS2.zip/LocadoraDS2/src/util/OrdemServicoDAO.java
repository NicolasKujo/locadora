package util;

import Tabela.Os;
import Telas.Ordens_de_Servico;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class OrdemServicoDAO {
    
    private Session sessao;
    
    public OrdemServicoDAO(){
        this.sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void Salvar(Os os){
        Transaction t = sessao.beginTransaction();
        sessao.saveOrUpdate(os);
        t.commit();
    }
    
    public void Editar(Os os){
        Transaction t = sessao.beginTransaction();
        sessao.update(os);
        t.commit();
    }
        
    public void Excluir(Os os){
        Transaction t = sessao.beginTransaction();
        sessao.delete(os);
        t.commit();
    }
    
    public Os Buscar(int codigo, Os os){
        Transaction t = sessao.beginTransaction();
        Tabela.Os Ordemservico = new Tabela.Os();
        try{
            os = (Os) sessao.get(Os.class, codigo);
            t.commit();
        }catch (Error e){
            System.out.println(e.getMessage());
        }
        sessao.close();
        return os;
    }
    
    public List<Os>BuscarOrden_de_Servico(String texto){
        int numero = 0;
        try{
            numero = Integer.valueOf(texto);
        } catch(NumberFormatException e){
            System.out.println("O " + texto + " não é um numero.");
        }
        texto = "%" + texto + "%";
        
        Query query = sessao.createQuery("from Ordens de Servico" + "where codigo os = :cod or nome like :detalhe");
        query.setInteger("cod", numero);
        query.setString("detalhe", texto);
        
        List<Os> ods = (List<Os>) query.list();
        return ods;
        
    }

}
