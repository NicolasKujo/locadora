package util;

import Telas.Inicio;
import classes.Usuario;
import javax.swing.JOptionPane;
import org.hibernate.Query;
import org.hibernate.Session;

public class UsuarioDAO {
     
    private Session sessao;
     
    public void VerificarUsuario(String login, String senha){
       
        /*public Usuario Verifica(String login, String senha){
            Usuario usuario;
            Query query = sessao.createQuery("from Usuario where login = :login and senha =:senha");
            query.setString("login" , login);
            query.setString("senha" , senha);
            usuario = (Usuario) query.uniqueResult();
            return usuario;
        }*/
        
        if((senha.equals("123456")) && login.equals("aulads")){
            JOptionPane.showMessageDialog(null, "Usuario correto, bem vindo ao sistema!");
            
            Inicio inicio1 = new Inicio();
            
            inicio1.chamar();
            
        }else{
            JOptionPane.showMessageDialog(null, "Usuario incorreto");
        }
    }
}
   


    


