package util;

import Tabela.Veiculos;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class VeiculoDAO {
    
    private Session sessao;
    
    public VeiculoDAO(){
        this.sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void Salvar(Veiculos veiculo){
        Transaction t = sessao.beginTransaction();
        sessao.saveOrUpdate(veiculo);
        t.commit();
    }
    
    public void Editar(Veiculos veiculo){
        Transaction t = sessao.beginTransaction();
        sessao.update(veiculo);
        t.commit();
    }
        
    public void Excluir(Veiculos veiculo){
        Transaction t = sessao.beginTransaction();
        sessao.delete(veiculo);
        t.commit();
    }
    
    public Veiculos Buscar(int codigo, Veiculos veiculo){
        Transaction t = sessao.beginTransaction();
        Tabela.Veiculos veiculos = new Tabela.Veiculos();
        try{
            veiculo = (Veiculos) sessao.get(Veiculos.class, codigo);
            t.commit();
        }catch (Error e){
            System.out.println(e.getMessage());
        }
        sessao.close();
        return veiculo;
    }
    
    public List<Veiculos>BuscarCliente(String texto){
        int numero = 0;
        try{
            numero = Integer.valueOf(texto);
        } catch(NumberFormatException e){
            System.out.println("O " + texto + " não é um numero.");
        }
        texto = "%" + texto + "%";
        
        Query query = sessao.createQuery("from Veiculo" + "where placa = :cod or nome like :detalhe");
        query.setInteger("cod", numero);
        query.setString("detalhe", texto);
        
        List<Veiculos> vei = (List<Veiculos>) query.list();
        return vei;
        
    }

}